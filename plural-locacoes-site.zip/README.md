# Plural Locações — Site (React + Vite + Tailwind)
## Rodar
npm install
npm run dev
## Troque o video e imagens
- Coloque o video em `public/video01.mp4` (ou edite `src/components/VideoHero.jsx`).
- Troque `public/imagem*.jpg` pelas suas fotos.
